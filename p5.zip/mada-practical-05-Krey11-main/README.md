# mada-practical-05-hitarthraval
This is the Practical 05 of 'Mobile Application Development using Android (mada)' subject of 6th sem B.Tech Computer Engineering Branch, Sankalchand Patel College Of Engineering.
<hr>
<b>AIM: </b> Create an Android app to Implement an implicit Intent that opens a web page, and another that opens a location on a map. Also, Implement an action to share a snippet of text.
<br>
<hr>
